<<<<<<< HEAD
<<<<<<< HEAD
---
title: Mana Basha
emoji: 👀
colorFrom: blue
colorTo: indigo
sdk: gradio
sdk_version: 5.38.2
app_file: app.py
pinned: false
license: mit
short_description: 'Multilingual, offline-first Telugu corpus collector via fun '
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference


